<?php

/*--------------------------------------------------------------
# Copyright (C) joomla-monster.com
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
# Website: http://www.joomla-monster.com
# Support: info@joomla-monster.com
---------------------------------------------------------------*/

defined('_JEXEC') or die;

class JMTemplate extends JMFTemplate {
	public function postSetUp() {

		$bootstrap_vars = array();

		/* Template Layout */

		$templatefluidwidth = $this->params->get('JMfluidGridContainerLg', $this->defaults->get('JMfluidGridContainerLg'));
		$bootstrap_vars['JMfluidGridContainerLg'] = $templatefluidwidth;

		$gutterwidth = $this->params->get('JMbaseSpace', $this->defaults->get('JMbaseSpace'));
		$bootstrap_vars['JMbaseSpace'] = $gutterwidth;

		$offcanvaswidth = $this->params->get('JMoffCanvasWidth', $this->defaults->get('JMoffCanvasWidth'));
		$bootstrap_vars['JMoffCanvasWidth'] = $offcanvaswidth;

				/* Font Modifications */

				//body

				$bodyfontsize = (int)$this->params->get('JMbaseFontSize', $this->defaults->get('JMbaseFontSize'));
		$bootstrap_vars['JMbaseFontSize'] = $bodyfontsize.'px';

				$bodyfonttype = $this->params->get('bodyFontType', $this->defaults->get('bodyFontType'));
				$bodyfontfamily = $this->params->get('bodyFontFamily', $this->defaults->get('bodyFontFamily'));
		$bodygooglewebfontfamily = $this->params->get('bodyGoogleWebFontFamily', $this->defaults->get('bodyGoogleWebFontFamily'));
				$bodygeneratedwebfontfamily = $this->params->get('bodyGeneratedWebFont');

				switch($bodyfonttype) {
						case "0" : {
								$bootstrap_vars['JMbaseFontFamily'] = $bodyfontfamily;
								break;
						}
					case "1" :{
								$bootstrap_vars['JMbaseFontFamily'] = $bodygooglewebfontfamily;
								break;
						}
						case "2" :{
							$bootstrap_vars['JMbaseFontFamily'] = $bodygeneratedwebfontfamily;
							break;
						}
						default: {
								$bootstrap_vars['JMbaseFontFamily'] = $this->defaults->get('bodyGoogleWebFontFamily');
								break;
						}
				 }

			 //module title

		 $headingsfontsize = (int)$this->params->get('JMmoduleTitleFontSize', $this->defaults->get('JMmoduleTitleFontSize'));
		$bootstrap_vars['JMmoduleTitleFontSize'] = $headingsfontsize.'px';

		$headingsfonttype = $this->params->get('headingsFontType', $this->defaults->get('headingsFontType'));
		$headingsfontfamily = $this->params->get('headingsFontFamily', $this->defaults->get('headingsFontFamily'));
		$headingsgooglewebfontfamily = $this->params->get('headingsGoogleWebFontFamily', $this->defaults->get('headingsGoogleWebFontFamily'));
		$headingsgeneratedwebfontfamily = $this->params->get('headingsGeneratedWebFont');

				switch($headingsfonttype) {
						case "0" : {
								$bootstrap_vars['JMmoduleTitleFontFamily'] = $headingsfontfamily;
								break;
						}
						case "1" :{
								$bootstrap_vars['JMmoduleTitleFontFamily'] = $headingsgooglewebfontfamily;
								break;
						}
						case "2" :{
							$bootstrap_vars['JMmoduleTitleFontFamily'] = $headingsgeneratedwebfontfamily;
							break;
						}
						default: {
								$bootstrap_vars['JMmoduleTitleFontFamily'] = $this->defaults->get('headingsGoogleWebFontFamily');
								break;
						}
				 }

		//top menu horizontal

		$djmenufontsize = (int)$this->params->get('JMtopmenuFontSize', $this->defaults->get('JMtopmenuFontSize'));
		$bootstrap_vars['JMtopmenuFontSize'] = $djmenufontsize.'px';

		$djmenufonttype = $this->params->get('djmenuFontType', $this->defaults->get('djmenuFontType'));
		$djmenufontfamily = $this->params->get('djmenuFontFamily', $this->defaults->get('djmenuFontFamily'));
		$djmenugooglewebfontfamily = $this->params->get('djmenuGoogleWebFontFamily', $this->defaults->get('djmenuGoogleWebFontFamily'));
		$djmenugeneratedwebfontfamily = $this->params->get('djmenuGeneratedWebFont');

				switch($djmenufonttype) {
						case "0" : {
								$bootstrap_vars['JMtopmenuFontFamily'] = $djmenufontfamily;
								break;
						}
						case "1" :{
								$bootstrap_vars['JMtopmenuFontFamily'] = $djmenugooglewebfontfamily;
								break;
						}
						case "2" :{
							$bootstrap_vars['JMtopmenuFontFamily'] = $djmenugeneratedwebfontfamily;
							break;
						}
						default: {
								$bootstrap_vars['JMtopmenuFontFamily'] = $this->defaults->get('djmenuGoogleWebFontFamily');
								break;
						}
				 }

		//blog title

		$blogfontsize = (int)$this->params->get('JMblogTitleFontSize', $this->defaults->get('JMblogTitleFontSize'));
		$bootstrap_vars['JMblogTitleFontSize'] = $blogfontsize.'px';

		$blogfonttype = $this->params->get('blogFontType', '1');
		$blogfontfamily = $this->params->get('blogFontFamily', $this->defaults->get('blogFontFamily'));
		$bloggooglewebfontfamily = $this->params->get("blogGoogleWebFontFamily", $this->defaults->get('blogGoogleWebFontFamily'));
		$bloggeneratedfontfamily = $this->params->get('blogGeneratedWebFont');

		switch($blogfonttype) {
			case "0" : {
				$bootstrap_vars['JMblogTitleFontFamily'] = $blogfontfamily;
				break;
			}
			case "1" :{
				$bootstrap_vars['JMblogTitleFontFamily'] = $bloggooglewebfontfamily;
				break;
			}
			case "2" :{
				$bootstrap_vars['JMblogTitleFontFamily'] = $bloggeneratedfontfamily;
				break;
			}
			default: {
				$bootstrap_vars['JMblogTitleFontFamily'] = $this->defaults->get('JMblogTitleFontFamily');
				break;
			}
		}

		//article title

		$articlesfontsize = (int)$this->params->get('JMarticleTitleFontSize', $this->defaults->get('JMarticleTitleFontSize'));
		$bootstrap_vars['JMarticleTitleFontSize'] = $articlesfontsize.'px';

		$articlesfonttype = $this->params->get('articlesFontType', $this->defaults->get('articlesFontType'));
		$articlesfontfamily = $this->params->get('articlesFontFamily', $this->defaults->get('articlesFontFamily'));
		$articlesgooglewebfontfamily = $this->params->get('articlesGoogleWebFontFamily');
		$articlesgeneratedfontfamily = $this->params->get('articlesGeneratedWebFont');

				switch($articlesfonttype) {
						case "0" : {
								$bootstrap_vars['JMarticleTitleFontFamily'] = $articlesfontfamily;
								break;
						}
						case "1" :{
								$bootstrap_vars['JMarticleTitleFontFamily'] = $articlesgooglewebfontfamily;
								break;
						}
						case "2" :{
							$bootstrap_vars['JMarticleTitleFontFamily'] = $articlesgeneratedfontfamily;
							break;
						}
						default: {
								$bootstrap_vars['JMarticleTitleFontFamily'] = $this->defaults->get('articlesFontFamily');
								break;
						}
				 }

			/* Color Modifications */

			//scheme color
				$colorversion = $this->params->get('JMcolorVersion', $this->defaults->get('JMcolorVersion'));
		$bootstrap_vars['JMcolorVersion'] = $colorversion;

			//global
				$pagebackground = $this->params->get('JMpageBackground', $this->defaults->get('JMpageBackground'));
		$bootstrap_vars['JMpageBackground'] = $pagebackground;

				$bodyfontcolor = $this->params->get('JMbaseFontColor', $this->defaults->get('JMbaseFontColor'));
		$bootstrap_vars['JMbaseFontColor'] = $bodyfontcolor;

				$componentbackground = $this->params->get('JMcomponentBackground', $this->defaults->get('JMcomponentBackground'));
		$bootstrap_vars['JMcomponentBackground'] = $componentbackground;

				$componentborder = $this->params->get('JMcomponentBorder', $this->defaults->get('JMcomponentBorder'));
		$bootstrap_vars['JMcomponentBorder'] = $componentborder;

				$articlefontcolor = $this->params->get('JMarticleFontColor', $this->defaults->get('JMarticleFontColor'));
		$bootstrap_vars['JMarticleFontColor'] = $articlefontcolor;

		//topbar
				$topbarbackground = $this->params->get('JMtopbarBackground', $this->defaults->get('JMtopbarBackground'));
		$bootstrap_vars['JMtopbarBackground'] = $topbarbackground;

				$topbarborder = $this->params->get('JMtopbarBorder', $this->defaults->get('JMtopbarBorder'));
		$bootstrap_vars['JMtopbarBorder'] = $topbarborder;

				$topbarfontcolor = $this->params->get('JMtopbarFontColor', $this->defaults->get('JMtopbarFontColor'));
		$bootstrap_vars['JMtopbarFontColor'] = $topbarfontcolor;

		//menubar
				$topmenubackground = $this->params->get('JMtopmenuBackground', $this->defaults->get('JMtopmenuBackground'));
		$bootstrap_vars['JMtopmenuBackground'] = $topmenubackground;

				$topmenuborder = $this->params->get('JMtopmenuBorder', $this->defaults->get('JMtopmenuBorder'));
		$bootstrap_vars['JMtopmenuBorder'] = $topmenuborder;

				$topmenufontcolor = $this->params->get('JMtopmenuFontColor', $this->defaults->get('JMtopmenuFontColor'));
		$bootstrap_vars['JMtopmenuFontColor'] = $topmenufontcolor;

		//modules
				$modulebackground = $this->params->get('JMmoduleBackground', $this->defaults->get('JMmoduleBackground'));
		$bootstrap_vars['JMmoduleBackground'] = $modulebackground;

				$moduleborder = $this->params->get('JMmoduleBorder', $this->defaults->get('JMmoduleBorder'));
		$bootstrap_vars['JMmoduleBorder'] = $moduleborder;

				$modulefontcolor = $this->params->get('JMmoduleFontColor', $this->defaults->get('JMmoduleFontColor'));
		$bootstrap_vars['JMmoduleFontColor'] = $modulefontcolor;

				$colorbox1background = $this->params->get('JMcolorBox1Background', $this->defaults->get('JMcolorBox1Background'));
		$bootstrap_vars['JMcolorBox1Background'] = $colorbox1background;

				$colorbox2background = $this->params->get('JMcolorBox2Background', $this->defaults->get('JMcolorBox2Background'));
		$bootstrap_vars['JMcolorBox2Background'] = $colorbox2background;

				$colorbox3background = $this->params->get('JMcolorBox3Background', $this->defaults->get('JMcolorBox3Background'));
		$bootstrap_vars['JMcolorBox3Background'] = $colorbox3background;

		//footer
				$footerbackground = $this->params->get('JMfooterBackground', $this->defaults->get('JMfooterBackground'));
		$bootstrap_vars['JMfooterBackground'] = $footerbackground;

				$footerborder = $this->params->get('JMfooterBorder', $this->defaults->get('JMfooterBorder'));
		$bootstrap_vars['JMfooterBorder'] = $footerborder;

				$footerfontcolor = $this->params->get('JMfooterFontColor', $this->defaults->get('JMfooterFontColor'));
		$bootstrap_vars['JMfooterFontColor'] = $footerfontcolor;

		//offcanvas
				$offcanvasbackground = $this->params->get('JMoffCanvasBackground', $this->defaults->get('JMoffCanvasBackground'));
		$bootstrap_vars['JMoffCanvasBackground'] = $offcanvasbackground;

				$offcanvasfontcolor = $this->params->get('JMoffCanvasFontColor', $this->defaults->get('JMoffCanvasFontColor'));
		$bootstrap_vars['JMoffCanvasFontColor'] = $offcanvasfontcolor;

				 $this->params->set('jm_bootstrap_variables', $bootstrap_vars);

				$this->lessMap['bootstrap.less'] = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'override/ltr/scaffolding.less',
						'override/ltr/type.less',
						'override/ltr/forms.less',
						'override/ltr/tables.less',
						'override/ltr/dropdowns.less',
						'override/ltr/wells.less',
						'override/ltr/buttons.less',
						'override/ltr/button-groups.less',
						'override/ltr/navs.less',
						'override/ltr/navbar.less',
						'override/ltr/breadcrumbs.less',
						'override/ltr/pagination.less',
						'override/ltr/pager.less',
						'override/ltr/labels-badges.less',
						'override/ltr/accordion.less'
				);

				$this->lessMap['bootstrap_rtl.less'] = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'override/rtl/scaffolding.less',
						'override/rtl/type.less',
						'override/rtl/forms.less',
						'override/rtl/tables.less',
						'override/rtl/dropdowns.less',
						'override/rtl/wells.less',
						'override/rtl/buttons.less',
						'override/rtl/button-groups.less',
						'override/rtl/navs.less',
						'override/rtl/navbar.less',
						'override/rtl/breadcrumbs.less',
						'override/rtl/pagination.less',
						'override/rtl/pager.less',
						'override/rtl/labels-badges.less',
						'override/rtl/accordion.less'
				);

				$this->lessMap['bootstrap_responsive.less'] = array(
						'bootstrap_variables.less',
						'override/ltr/responsive-767px-max.less'
				);

				$this->lessMap['bootstrap_responsive_rtl.less'] = array(
						'bootstrap_variables.less',
						'override/rtl/responsive-767px-max.less'
				);

				$this->lessMap['template.less'] = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'template_mixins.less',
						'layout.less',
						'modules.less',
						'joomla.less',
						'editor.less',
						'djimageslider.less'
				);

				$this->lessMap['template_rtl.less'] = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'template_mixins.less',
						'djmenu_rtl.less',
						'djimageslider_rtl.less'
				);

				$this->lessMap['template_responsive.less'] = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'template_mixins.less',
						'djimageslider_responsive.less'
				);

				$common_all = array(
						'bootstrap_variables.less',
						'template_variables.less',
						'template_mixins.less'
				);

				$this->lessMap['offcanvas.less'] = $common_all;
				$this->lessMap['djmenu.less'] = $common_all;
				$this->lessMap['djmenu_fx.less'] = $common_all;
				$this->lessMap['djmegamenu.less'] = $common_all;
				$this->lessMap['djmegamenu_rtl.less'] = $common_all;
				$this->lessMap['custom.less'] = $common_all;
				$this->lessMap['comingsoon.less'] = $common_all;

		/**
		 * List of URLs parts that should be removed/replaced from head
		 * Example:
		 *
		 * $urlsToRemove = array(
						//removing file completely
						'components/com_djclassifieds/themes/jm-real-estate-ads/css/responsive.css'     => false,

						// replacing with another css file
						'templates/jm-dating/css/djmegamenu.css                                         => array('url' => 'new/URL/file.css', 'type' => 'css'),

						// replacing with LESS file
						'components/com_djcatalog2/themes/jm-real-estate-ads/css/theme.css'             => array('url' => 'new/URL/file.less', 'type' => 'less')
				);
		 */

		//offline page
				$this->CompileStyleSheet(JPath::clean(JMF_TPL_PATH.'/less/offline.less'), true);

				 //compile less to css
		$djmenu_css = $this->compileStyleSheet(JPath::clean(JMF_TPL_PATH.'/less/djmenu.less'), true, true);
		$djmenu_fx_css = $this->compileStyleSheet(JPath::clean(JMF_TPL_PATH.'/less/djmenu_fx.less'), true, true);

		$djmegamenu_css = $this->compileStyleSheet(JPath::clean(JMF_TPL_PATH.'/less/djmegamenu.less'), true, true);
		$djmegamenu_css_rtl = $this->compileStyleSheet(JPath::clean(JMF_TPL_PATH.'/less/djmegamenu_rtl.less'), true, true);

				$themer = (int)$this->params->get('themermode', 0) == 1 ? true : false;
				$app = JFactory::getApplication();
				if ($themer) {
						$urlsToRemove = array(
							'templates/'.$app->getTemplate().'/css/djmenu.css' => array('url' => 'templates/'.$app->getTemplate().'/less/djmenu.less', 'type' => 'less'),
							'templates/'.$app->getTemplate().'/css/djmenu_fx.css' => array('url' => 'templates/'.$app->getTemplate().'/less/djmenu_fx.less', 'type' => 'less'),
							'templates/'.$app->getTemplate().'/css/djmegamenu.css' => array('url' => 'templates/'.$app->getTemplate().'/less/djmegamenu.less', 'type' => 'less'),
							'templates/'.$app->getTemplate().'/css/djmegamenu_rtl.css' => array('url' => 'templates/'.$app->getTemplate().'/less/djmegamenu_rtl.less', 'type' => 'less')
						);
						$app->set('jm_remove_stylesheets', $urlsToRemove);
				} else {
						$urlsToRemove = array(
								'templates/'.$app->getTemplate().'/css/djmenu.css' => array('url' => $djmenu_css, 'type' => 'css'),
								'templates/'.$app->getTemplate().'/css/djmenu_fx.css' => array('url' => $djmenu_fx_css, 'type' => 'css'),
								'templates/'.$app->getTemplate().'/css/djmegamenu.css' => array('url' => $djmegamenu_css, 'type' => 'css'),
								'templates/'.$app->getTemplate().'/css/djmegamenu_rtl.css' => array('url' => $djmegamenu_css_rtl, 'type' => 'css')
						);
						$app->set('jm_remove_stylesheets', $urlsToRemove);
				}
		}
}
