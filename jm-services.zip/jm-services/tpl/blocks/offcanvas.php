<?php
/*--------------------------------------------------------------
# Copyright (C) joomla-monster.com
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
# Website: http://www.joomla-monster.com
# Support: info@joomla-monster.com
---------------------------------------------------------------*/

defined('_JEXEC') or die;

?>

<div id="jm-offcanvas">
	<div id="jm-offcanvas-toolbar">
		<a class="toggle-nav close-menu"><span class="icon-remove"></span></a>
	</div>
	<div id="jm-offcanvas-content">
		<jdoc:include type="modules" name="offcanvas" style="jmmodule" />
	</div>
</div>