jQuery(document).ready(function($) {

	//lazyloading
	var items = $('img[data-original], iframe[data-original]');

	function loadImage( img ) {
		//console.log(img);
		img.data();
		var src = img.data('original');
		img.removeAttr('data-original');
		img.attr('src', src);
	}

	if ( 'loading' in HTMLImageElement.prototype ) { //native browser
		//console.log('native lazy load');

		items.each(function(){
			loadImage( $(this) );
		});
	} else if ( 'IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype ) { //observer
		//console.log('observer lazy load');

		var config = {
			rootMargin: '0px 0px 50px 0px',
			threshold: 0
		}

		var observer = new IntersectionObserver(function (entries, self) {
			$.each(entries, function(i, entry) {
				if (entry.isIntersecting) { //show on viewport
					// load the image
					loadImage( $(entry.target) );
					// Stop watching
					self.unobserve(entry.target);
				}
			});
		}, config);

		items.each(function() {
			observer.observe( this );
		});

	} else { // offset
	
		var lazyLoading = function(loadInvisible) {
			//console.log('offset lazy load');

			var viewport = $(window).scrollTop() + $(window).height();
		
			items.each(function() {
				var img = $(this);
				if(img.offset().top < viewport || (loadInvisible && img.is(':hidden'))) {
					loadImage( img );
				}
			});
		}

		// remove event if all images have been loaded
		if( ! items.length ) {
			$(window).off('scroll', lazyLoading);
			$(window).off('resize', lazyLoading);
			$(document).off('click', lazyLoading);
		}

		$(window).on('scroll', lazyLoading.bind(this, false));
		$(window).on('resize', lazyLoading.bind(this, false));
		$(document).on('click', lazyLoading.bind(this, true));
		lazyLoading(false);
	}

});
